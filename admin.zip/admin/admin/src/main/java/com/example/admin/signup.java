package com.example.admin;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class signup extends AppCompatActivity {

    private EditText numberInputText, codeInputText;
    private Button sendCodeBtn, confirmBtn;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_signup);

        numberInputText = findViewById(R.id.numberinput_text);
        codeInputText = findViewById(R.id.codeinput_text);
        sendCodeBtn = findViewById(R.id.sendcode_btn);
        confirmBtn = findViewById(R.id.confirm_btn);
        progressBar = findViewById(R.id.progressbar);

    }
}