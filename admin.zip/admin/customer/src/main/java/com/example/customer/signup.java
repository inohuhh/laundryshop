package com.example.customer;

import android.app.Activity;

public class signup extends Activity {
}
