package com.example.customer;

import android.app.Activity;

public class login_activity extends Activity {
}
