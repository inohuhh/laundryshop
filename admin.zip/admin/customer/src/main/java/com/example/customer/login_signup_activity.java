package com.example.customer;

import android.app.Activity;

public class login_signup_activity extends Activity {
}
